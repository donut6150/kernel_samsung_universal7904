
# wait when its done
while [ "$(getprop sys.boot_completed | tr -d '\r')" != "1" ]; do sleep 20; done

sync


# there are files to exec
sleep 2
sh /data/adb/modules/stellar/common/post-fs-data.sh
sh /data/adb/modules/stellar/service/stellar_obility
sleep 3
sh /data/adb/modules/stellar/service/stellar_spark
sleep 3
stellar_echos




