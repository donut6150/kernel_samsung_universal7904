
echo "Restarting Service by Action Button..."
echo "Close this app and open again.."
stellar_echos